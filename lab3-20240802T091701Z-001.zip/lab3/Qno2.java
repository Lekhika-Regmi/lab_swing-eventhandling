package lab3;

import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Qno2 {
    public Qno2() {
        JFrame jf = new JFrame();
        jf.setSize(1000,800);
        jf.setLayout(new GridLayout(2, 3));
        
        JLabel jl1 = new JLabel("Name");
        JLabel jl2 = new JLabel("Email");
        JTextField jtf1 = new JTextField();
        JTextField jtf2 = new JTextField();
        
        // Corrected paths with escaped backslashes or forward slashes
        ImageIcon icon1 = new ImageIcon("C:/Users/name.png");
        ImageIcon icon2 = new ImageIcon("C:/Users/Email_icon.png");
        
        // Create JLabels with icons
        JLabel iconLabel1 = new JLabel(icon1);
        JLabel iconLabel2 = new JLabel(icon2);
        
        
        jf.add(jl1);
        jf.add(jtf1);
        jf.add(iconLabel1); // Add JLabel containing icon
        jf.add(jl2);
        jf.add(jtf2);
        jf.add(iconLabel2); // Add JLabel containing icon
        
        jf.setSize(300, 300); // Set the size of the JFrame
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Ensure the application exits on close
        jf.setVisible(true);
    }
    
    public static void main(String[] args) {
        new Qno2();
    }
}
