package lab3;

import java.awt.Frame;
import java.awt.Label;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Qno1 {
    int x = 0, y = 0;
    Frame f;
    String strEvent = "";
    
    public Qno1() {
        f = new Frame("Java mouse event examples");
        f.setSize(400, 400);
        f.setLayout(null); // Ensure absolute positioning
        f.setVisible(true);
        Label l = new Label();
        l.setBounds(20, 50, 150, 20); // Set position and size for the label
        
        // Add the label to the frame
        f.add(l);

        f.addMouseListener(new MouseListener() {
            @Override
            public void mouseEntered(MouseEvent e) {
                strEvent = "MouseEntered";
              
                l.setText(strEvent);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                // Implement if needed
            	  strEvent = "Mouse Clicked";
                  x = e.getX();
                  y = e.getY();
                  l.setText(strEvent + " at (" + x + ", " + y + ")");
            }

            @Override
            public void mousePressed(MouseEvent e) {
                // Implement if needed
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                // Implement if needed
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Implement if needed
            	  strEvent = "Mouse exited";
                
                  l.setText(strEvent);
            }
        });

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                f.dispose();
            }
        });
    }

    public static void main(String[] args) {
        new Qno1();
    }
}
